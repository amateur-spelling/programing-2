//Prog 2a
//Practice problem to learn how to use the editor and compil and run a program

#include <iostream.h>
void main()
{
cout<<"The program you\n";
cout<<"are using is \n";
cout<<"called Pascal.  It\n";
cout<<"will soon be your friend.\n";
cout<<"Opps!! a mistake was\n";
cout<<"just made.  Please\n";
cout<<"correct me.\n";
}


